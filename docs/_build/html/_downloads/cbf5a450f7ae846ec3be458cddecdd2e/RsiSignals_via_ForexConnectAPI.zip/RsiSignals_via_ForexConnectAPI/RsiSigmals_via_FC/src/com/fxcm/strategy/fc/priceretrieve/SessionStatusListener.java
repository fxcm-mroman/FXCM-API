package com.fxcm.strategy.fc.priceretrieve;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import com.fxcore2.*;

public class SessionStatusListener implements IO2GSessionStatus {

	private boolean connected;
	private Semaphore semaphore;

	public SessionStatusListener() {
		this.connected = false;
		this.semaphore = new Semaphore(0);
	}

	public boolean isConnected() {
		return connected;
	}

	@Override
	public void onSessionStatusChanged(O2GSessionStatusCode status) {
		System.out.println("Status: " + status.toString());
		switch (status) {
		case CONNECTED:
			connected = true;
			semaphore.release();
			break;
		case DISCONNECTED:
			connected = false;
			semaphore.release();
			break;
		}
	}

	@Override
	public void onLoginFailed(String error) {
		System.out.println("Login error: " + error);
	}

	public boolean waitEvents() throws Exception {
		// timeout for 30 seconds unless connection is established
		return semaphore.tryAcquire(30, TimeUnit.SECONDS);
	}

}
