package com.fxcm.strategy.fc.buildstrategy;

import java.util.List;

import com.fxcm.strategy.fc.priceretrieve.Candlestick;


public interface Strategy {
	StrategyResult runSrtategy(List <Candlestick> candleStickList);
}
