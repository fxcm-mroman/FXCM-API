package com.fxcm.strategy.fc.priceretrieve;

import java.util.Comparator;
import java.util.Date;

public class Candlestick implements Comparator<Candlestick> {

	private Date date;
	private double open;
	private double low;
	private double high;
	private double close;
	private double volume;
	private double rsi;

	public Candlestick(Date date, double open, double low, double high, double close, double volume) {
		this.date = date;
		this.open = open;
		this.low = low;
		this.high = high;
		this.close = close;
		this.volume = volume;
	}

	public Candlestick() {
	}
	// getters and setters goes here...

	
	
	public Date getDate() {
		return date;
	}

	public double getRsi() {
		return rsi;
	}

	public void setRsi(double rsi) {
		this.rsi = rsi;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getOpen() {
		return open;
	}

	public void setOpen(double open) {
		this.open = open;
	}

	public double getLow() {
		return low;
	}

	public void setLow(double low) {
		this.low = low;
	}

	public double getHigh() {
		return high;
	}

	public void setHigh(double high) {
		this.high = high;
	}

	public double getClose() {
		return close;
	}

	public void setClose(double close) {
		this.close = close;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	@Override
	public int compare(Candlestick o1, Candlestick o2) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}
