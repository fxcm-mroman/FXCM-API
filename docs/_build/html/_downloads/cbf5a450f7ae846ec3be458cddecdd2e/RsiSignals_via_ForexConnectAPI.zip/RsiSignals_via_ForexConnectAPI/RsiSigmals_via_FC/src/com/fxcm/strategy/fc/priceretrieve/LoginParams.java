package com.fxcm.strategy.fc.priceretrieve;

public class LoginParams {

	// define error messages for lack of obligatory parameters.
	public static final String MISSING_PARAMETERS = "Some login parameters are missing.";
	public static final String LOGIN_NOT_SPECIFIED = "'Login' is not specified";
	public static final String PASSWORD_NOT_SPECIFIED = "'Password' is not specified";
	public static final String URL_NOT_SPECIFIED = "'URL' is not specified";
	public static final String CONNECTION_NOT_SPECIFIED = "'Connection' is not specified. For example \"Demo\" or \"Real\"";
	private String login;
	private String password;
	private String url;
	private String connection;

	// constructor#1: arguments provided literally
	public LoginParams(String login, String password, String url, String connection) throws Exception {
		this.login = login;
		this.password = password;
		this.url = url;
		this.connection = connection;
		checkObligatoryParams();
	}

	// constructor#2: argument from main method
	public LoginParams(String[] args) throws Exception {
		if (args.length < 4)
			throw new Exception(MISSING_PARAMETERS);
		this.login = args[0];
		this.password = args[1];
		this.url = args[2];
		this.connection = args[3];
		checkObligatoryParams();
	}

	// getters goes here...
	private void checkObligatoryParams() throws Exception {
		if (this.login.isEmpty())
			throw new Exception(LOGIN_NOT_SPECIFIED);
		if (this.password.isEmpty())
			throw new Exception(PASSWORD_NOT_SPECIFIED);
		if (this.url.isEmpty())
			throw new Exception(URL_NOT_SPECIFIED);
		if (this.connection.isEmpty())
			throw new Exception(CONNECTION_NOT_SPECIFIED);
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getConnection() {
		return connection;
	}

	public void setConnection(String connection) {
		this.connection = connection;
	}
	
	
	
}
