package com.fxcm.strategy.fc.backtest;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import com.fxcm.strategy.fc.buildstrategy.RsiSignals;
import com.fxcm.strategy.fc.buildstrategy.StrategyResult;
import com.fxcm.strategy.fc.buildstrategy.Strategy;
import com.fxcm.strategy.fc.priceretrieve.Candlestick;
import com.fxcm.strategy.fc.priceretrieve.HistoryMiner;
import com.fxcm.strategy.fc.priceretrieve.LoginParams;
import com.fxcm.strategy.fc.priceretrieve.ResponseListener;
import com.fxcm.strategy.fc.priceretrieve.SampleParams;
import com.fxcm.strategy.fc.priceretrieve.SessionStatusListener;
import com.fxcore2.O2GSession;
import com.fxcore2.O2GTransport;


public class BacktestTester {

	static List<Candlestick> candlesticksList;

	public static void main(String[] args) {
		O2GSession session = null;
		double stopLossPerc = 0.003;
		double takeProfitPerc = 0.003;
		int bottomRSI = 10;
		List<StrategyResult> strategySummary = new ArrayList<StrategyResult>();
		
		try {
			LoginParams loginParams = new LoginParams("d101592791", "d101592791",
					"http://www.fxcorporate.com/Hosts.jsp", "Demo");
			SampleParams sampleParams = new SampleParams("EUR/USD", "m1", "01.11.2017 00:00", "");
			// if you supply parameters from the command line
			/*
			 * LoginParams loginParams = new LoginParams(args); SampleParams
			 * sampleParams = new SampleParams(args);
			 */
			// Tester class continued...
			session = O2GTransport.createSession();
			SessionStatusListener statusListener = new SessionStatusListener();
			session.subscribeSessionStatus(statusListener);
			session.login(loginParams.getLogin(), loginParams.getPassword(), loginParams.getUrl(),
					loginParams.getConnection());
			if (statusListener.waitEvents() && statusListener.isConnected()) {
				// connected...
				ResponseListener responseListener = new ResponseListener();
				session.subscribeResponse(responseListener);
				HistoryMiner.getHistoricalPrices(session, sampleParams, responseListener);
				session.logout();
				statusListener.waitEvents();
				session.unsubscribeResponse(responseListener);
			} else {
				System.out.println("Timeout expired before connection could be established");
			}
			session.unsubscribeSessionStatus(statusListener);
			if (HistoryMiner.candlesticksList != null) {
				candlesticksList = HistoryMiner.candlesticksList;
				HistoryMiner.printHistoricalPrices(candlesticksList);
				RsiSignals.calculateRsiForDataSet(candlesticksList, 14);
				// Tester class continued...
				for (double i = stopLossPerc; i < stopLossPerc + 0.005; i += 0.0005) { // adjust
																						// stop
																						// loss
					for (double j = takeProfitPerc; j < takeProfitPerc + 0.005; j += 0.0005) { // adjust
																								// take
																								// profit
						for (int k = bottomRSI; k <= bottomRSI + 20; k += 5) { // adjust
																				// bottom
																				// and
																				// top
																				// rsi
							Strategy rsiSignals = new RsiSignals(i, j, k);
							StrategyResult sr = ((RsiSignals) rsiSignals).runSrtategy(candlesticksList);
							strategySummary.add(sr);
						}
					}
				}
				Collections.sort(strategySummary, new StrategyResult()); // sort
																			// results
																			// list
				double avergeProfit = StrategyResult.calculateAvgStrategyProfit(strategySummary);
				System.out.println("Average profit=> " + (double) Math.round(10000 * avergeProfit) / 100 + "%");
				System.out.println("10 best results ______________________________________________________________ ");
				for (int i = 0; i < 10; i++) {
					RsiSignals rs = (RsiSignals) strategySummary.get(i).getStrategy();
					System.out.println("profit:" + (double) Math.round(strategySummary.get(i).getProfit() * 10000) / 100
							+ "%" + " | max-drawdown:"
							+ (double) Math.round(strategySummary.get(i).getMaxDrawdown() * 10000) / 100 + "%" + " | wins:"
							+ (double) Math.round(10000 * strategySummary.get(i).getWinsRatio()) / 100 + "%" + " | losses:"
							+ (double) Math.round(10000 * strategySummary.get(i).getLossesRatio()) / 100 + "%" + " | s-l:"
							+ (double) Math.round(rs.getStopLoss() * 10000) / 100 + "%" + " | t-p:"
							+ (double) Math.round(rs.getTakeProfit() * 10000) / 100 + "%" + " | bottom-rsi:"
							+ rs.getFloorRSI() + " | top-rsi:" + rs.getCeilingRSI() + "\n");
				}
				System.out.println("10 worst results _____________________________________________________________ ");
				for (int i = strategySummary.size() - 1; i > strategySummary.size() - 11; i--) {
					RsiSignals rs = (RsiSignals) strategySummary.get(i).getStrategy();
					System.out.println("profit: " + (double) Math.round(strategySummary.get(i).getProfit() * 10000) / 100
							+ "%" + " | max-drawdown:"
							+ (double) Math.round(strategySummary.get(i).getMaxDrawdown() * 10000) / 100 + "%" + " | wins:"
							+ (double) Math.round(10000 * strategySummary.get(i).getWinsRatio()) / 100 + "%" + " | losses:"
							+ (double) Math.round(10000 * strategySummary.get(i).getLossesRatio()) / 100 + "%" + " | s-l:"
							+ (double) Math.round(rs.getStopLoss() * 10000) / 100 + "%" + " | t-p:"
							+ (double) Math.round(rs.getTakeProfit() * 10000) / 100 + "%" + " | bottom-rsi:"
							+ rs.getFloorRSI() + " | top-rsi:" + rs.getCeilingRSI() + "\n");
				}
				
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e.toString());
		} finally {
			if (session != null)
				session.dispose();
		}
	}

}
