import pandas as pd
import json
import requests
from builtins import print
from socketIO_client import SocketIO
import time
import numpy as np
import matplotlib.pyplot as plt

TRADING_API_URL = 'https://api-demo.fxcm.com:443'
WEBSOCKET_PORT = 443
ACCESS_TOKEN  = 'ab36b9fd77ab4e08ac5d871d24874bec7cf5a62a'
def on_connect():
    print('Websocket Connected:' + socketIO._engineIO_session.id)
def on_close():
    print("Websocket Closed.")
socketIO = SocketIO(TRADING_API_URL, WEBSOCKET_PORT, params={'access_token': ACCESS_TOKEN})
socketIO.on('connect', on_connect)
socketIO.on('disconnect', on_close)
bearer_access_token = 'Bearer ' + socketIO._engineIO_session.id + ACCESS_TOKEN
method = '/candles/1/h1'
hist_response = requests.get(TRADING_API_URL + method,
                             headers = {
                                 'User-Agent': 'request',
                                 'Authorization': bearer_access_token,
                                 'Accept': 'application/json',
                                 'Content-Type': 'application/x-www-form-urlencoded'
                             },
                                params =  {
                                     'num': 100,
                                     'from': 1357002080,
                                     'to': 1483232460
                                }
                             )
if hist_response.status_code == 200:
    print("Data retrieved...")
    hist_data = hist_response.json()
    candle_data = hist_data['candles']
    df = pd.DataFrame(candle_data)
    df.columns = ['time', 'bidopen', 'bidclose', 'bidhigh', 'bidlow', 'askopen', 'askclose', 'askhigh', 'asklow', 'TickQty']
    df['time'] = pd.to_datetime(df['time'], unit='s')
    df = df.set_index('time')
    print(df)
    print(df.index)
    short_window = 40
    long_window = 100
    signals = pd.DataFrame(index=df.index)
    signals['signal'] = 0.0
    signals['short_mavg'] = df['bidclose'].rolling(window=short_window, min_periods=1, center=False).mean()
    signals['long_mavg'] = df['bidclose'].rolling(window=long_window, min_periods=1, center=False).mean()
    signals['signal'][short_window:] = np.where(signals['short_mavg'][short_window:]> signals['long_mavg'][short_window:], 1.0, 0.0)
    signals['positions'] = signals['signal'].diff()
    print(signals)
    initial_capital = float(100000.0)
    positions = pd.DataFrame(index=signals.index).fillna(0.0)
    positions['EUR/USD'] = 100 * signals['signal']
    portfolio = positions.multiply(df['bidclose'], axis=0)
    pos_diff = positions.diff()
    portfolio['holdings'] = (positions.multiply(df['bidclose'], axis=0)).sum(axis=1)
    portfolio['cash'] = initial_capital - (pos_diff.multiply(df['bidclose'], axis=0)).sum(axis=1).cumsum()
    portfolio['total'] = portfolio['cash'] + portfolio['holdings']
    portfolio['returns'] = portfolio['total'].pct_change()
    print(portfolio.head())
    fig = plt.figure()
    ax1 = fig.add_subplot(111, ylabel='Portfolio value in $')
    portfolio['total'].plot(ax=ax1, lw=2.)
    ax1.plot(portfolio.loc[signals.positions == 1.0].index,portfolio.total[signals.positions == 1.0],'^', markersize=10, color='m')
    ax1.plot(portfolio.loc[signals.positions == -1.0].index,portfolio.total[signals.positions == -1.0],'v', markersize=10, color='k')
    plt.show()
else:
    print(hist_response)



