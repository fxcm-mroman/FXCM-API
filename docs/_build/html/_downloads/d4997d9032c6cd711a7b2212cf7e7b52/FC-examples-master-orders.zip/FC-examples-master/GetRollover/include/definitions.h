#pragma once

#define bool int
typedef void * FXCHandle;
typedef double DATE;

typedef struct
{
    unsigned i;
    unsigned j;
    void *item;
} TableIterator;
