#ifdef WIN32
#define Order2Go2 __declspec(dllimport)
#else
#define Order2Go2
#endif

#include "interfaces_all.h"

