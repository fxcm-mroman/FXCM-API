
/*
    !!! Caution:
    Do not change anything in this source code because it was automatically generated
    from XML class description
*/

#pragma once

class SummariesTableColumnsEnum
{
 public:
   enum Columns 
   {  
     OfferID = 0,
     DefaultSortOrder = 1,
     Instrument = 2,
     SellNetPL = 3,
     SellNetPLPip = 4,
     SellAmount = 5,
     SellAvgOpen = 6,
     BuyClose = 7,
     SellClose = 8,
     BuyAvgOpen = 9,
     BuyAmount = 10,
     BuyNetPL = 11,
     BuyNetPLPip = 12,
     Amount = 13,
     GrossPL = 14,
     NetPL = 15,
     RolloverInterestSum = 16,
     UsedMargin = 17,
     UsedMarginBuy = 18,
     UsedMarginSell = 19,
     Commission = 20,
     CloseCommission = 21
   };
};
