Example C# program how to place If-then order, 
the main order is Limit Entry Sell with zero amount, 
the secondary order is Buy ELS order with Stop and Limit attached.