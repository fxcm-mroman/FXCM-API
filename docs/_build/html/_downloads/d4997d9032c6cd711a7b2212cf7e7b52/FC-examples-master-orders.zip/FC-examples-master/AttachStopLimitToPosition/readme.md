example program how to attach Stop and Limit to open position
the program will create market order then it will find the open position and attach Stop and Limit
