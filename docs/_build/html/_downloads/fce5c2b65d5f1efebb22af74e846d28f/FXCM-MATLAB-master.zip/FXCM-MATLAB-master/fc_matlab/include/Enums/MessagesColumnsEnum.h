
/*
    !!! Caution:
    Do not change anything in this source code because it was automatically generated
    from XML class description
*/

#pragma once

class MessageColumnsEnum
{
 public:
   enum Columns 
   {  
     MsgID = 0,
     Time = 1,
     From = 2,
     Type = 3,
     Feature = 4,
     Text = 5,
     Subject = 6,
     HTMLFragmentFlag = 7
   };
};

class MessageTableColumnsEnum
{
 public:
   enum Columns 
   {  
     MsgID = 0,
     Time = 1,
     From = 2,
     Type = 3,
     Feature = 4,
     Text = 5,
     Subject = 6,
     HTMLFragmentFlag = 7
   };
};
