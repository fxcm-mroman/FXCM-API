
void cb_sendMsg(char *msg, double msgType);


