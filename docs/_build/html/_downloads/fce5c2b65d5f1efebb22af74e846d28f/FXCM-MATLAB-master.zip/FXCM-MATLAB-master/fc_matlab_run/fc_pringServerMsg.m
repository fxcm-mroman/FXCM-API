function k = fc_pringServerMsg(msg, msgType )
    k = 1;
    display(msg);
    display(msgType);
    if (msgType == 1)
        
end

