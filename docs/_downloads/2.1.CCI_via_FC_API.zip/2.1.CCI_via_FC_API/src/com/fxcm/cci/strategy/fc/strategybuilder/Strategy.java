package com.fxcm.cci.strategy.fc.strategybuilder;

import java.util.List;

import com.fxcm.cci.strategy.fc.priceretriever.Candlestick;

public interface Strategy {
     
  StrategyResult runStrategy(List<Candlestick> candleStickList);
	
}
