package com.fxcm.cci.strategy.fc.strategybuilder;

import java.util.List;

import javax.swing.text.StyledEditorKit.ForegroundAction;

import com.fxcm.cci.strategy.fc.priceretriever.Candlestick;

public class SMAIndicator {
   
	
	protected Double calculateSMA(List<Double> listOfPrices, int duration){
		double smaOfTypicalPrices = (listOfPrices.stream().mapToDouble(Double::doubleValue).sum())/duration;
		return smaOfTypicalPrices;
	}
}
