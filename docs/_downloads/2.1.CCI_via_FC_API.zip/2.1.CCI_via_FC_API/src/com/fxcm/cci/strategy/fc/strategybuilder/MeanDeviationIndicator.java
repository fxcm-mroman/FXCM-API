package com.fxcm.cci.strategy.fc.strategybuilder;

import java.util.List;

import com.fxcm.cci.strategy.fc.priceretriever.Candlestick;

public class MeanDeviationIndicator {

	protected double calculateMeanDeviation(double average, List<Double> listOfPrices, int duration) {
		double sumOfDeviations = 0; 
		
		for (int j = 0; j < duration; j++) {
			 sumOfDeviations += Math.abs(average-listOfPrices.get(j));
			double meanDeviation = sumOfDeviations/duration;
			return meanDeviation;
		}
		return 0;
	}
}
