package com.fxcm.cci.strategy.fc.batester;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import com.fxcm.cci.strategy.fc.priceretriever.*;
import com.fxcm.cci.strategy.fc.strategybuilder.*;
import com.fxcore2.O2GSession;
import com.fxcore2.O2GTransport;
import com.fxcore2.*;

public class BacktestTester {

	static List<Candlestick> candlesticksList;

	public static void main(String[] args) {
		O2GSession session = null;
		double stopLoss=0.005;
		double takeProfit=0.003;
		int bottomLimitOfTheIndicator = -120;
		double averageProfit;
		List<StrategyResult> strategySummary = new ArrayList<StrategyResult>();
		
		try {
			LoginParams loginParams = new LoginParams("D25611997", "6925",
					"http://www.fxcorporate.com/Hosts.jsp", "Demo");
			SampleParams sampleParams = new SampleParams("EUR/USD", "m1", "01.11.2017 00:00", "01.12.2017 00:00");
			// if you supply parameters from the command line
			/*
			 * LoginParams loginParams = new LoginParams(args); SampleParams
			 * sampleParams = new SampleParams(args);
			 */
			// Tester class continued...
			session = O2GTransport.createSession();
			SessionStatusListener statusListener = new SessionStatusListener();
			session.subscribeSessionStatus(statusListener);
			session.login(loginParams.getLogin(), loginParams.getPassword(), loginParams.getUrl(),
					loginParams.getConnection());
			if (statusListener.waitEvents() && statusListener.isConnected()) {
				// connected...
				ResponseListener responseListener = new ResponseListener();
				session.subscribeResponse(responseListener);
				HistoryMiner.getHistoricalPrices(session, sampleParams, responseListener);
				session.logout();
				statusListener.waitEvents();
				session.unsubscribeResponse(responseListener);
			} else {
				System.out.println("Timeout expired before connection could be established");
			}
			session.unsubscribeSessionStatus(statusListener);
			if (HistoryMiner.candlesticksList != null) {
				candlesticksList = HistoryMiner.candlesticksList;
				HistoryMiner.printHistoricalPrices(candlesticksList);
				CCIIndicatorStrategy.calculateCciForDataSet(candlesticksList, 20);
				// Tester class continued...
				for (double i = stopLoss; i < stopLoss+0.010; i+=0.0001) {
					for (double j = takeProfit; j < takeProfit+0.010; j+=0.0005) {
						for (int k = bottomLimitOfTheIndicator; k <= bottomLimitOfTheIndicator+100; k+=5) {
							Strategy cciIndicator = new CCIIndicatorStrategy(i, j, k);
							StrategyResult sr = ((CCIIndicatorStrategy) cciIndicator).runStrategy(candlesticksList);
							strategySummary.add(sr);
						}
					}
				}
				Collections.sort(strategySummary, new StrategyResult()); // sort
				averageProfit = StrategyResult.calculateAvgStrategyProfit(strategySummary);
				System.out.println("Average profit=> "+(double)Math.round(10000*averageProfit)/100+ "%");
				System.out.println("10 best results ______________________________________________________________ ");
				for (int i = 0; i < 10; i++) {
					CCIIndicatorStrategy bos = (CCIIndicatorStrategy) strategySummary.get(i).getStrategy();
					System.out.println("profit:"+(double)Math.round(strategySummary.get(i).getProfit()*10000)/100 +"%" +
							" | max-drawdown:"+(double)Math.round(strategySummary.get(i).getMaxDrawdown()*10000)/100 +"%" +
							" | wins:"+(double)Math.round(10000*strategySummary.get(i).getWinsRatio())/100 + "%" +
							" | losses:"+(double)Math.round(10000*strategySummary.get(i).getLossesRatio())/100 + "%" +
							" | s-l:"+(double)Math.round(bos.getSTOP_LOSS()*10000)/100 +"%" +
							" | t-p:"+(double)Math.round(bos.getTAKE_PROFIT()*10000)/100 +"%" +
							" | bottom-Donchian:"+bos.getFLOOR_CCI() +
							" | top-DOnchian:"+bos.getCEILING_CCI() + "\n");
				}
				System.out.println("10 worst results _____________________________________________________________ ");
				for (int i = strategySummary.size()-1; i > strategySummary.size()-11; i--) {
					CCIIndicatorStrategy bos = (CCIIndicatorStrategy) strategySummary.get(i).getStrategy();
					System.out.println("profit:"+(double)Math.round(strategySummary.get(i).getProfit()*10000)/100 +"%" +
							" | max-drawdown:"+(double)Math.round(strategySummary.get(i).getMaxDrawdown()*10000)/100 +"%" +
							" | wins:"+(double)Math.round(10000*strategySummary.get(i).getWinsRatio())/100 + "%" +
							" | losses:"+(double)Math.round(10000*strategySummary.get(i).getLossesRatio())/100 + "%" +
							" | s-l:"+(double)Math.round(bos.getSTOP_LOSS()*10000)/100 +"%" +
							" | t-p:"+(double)Math.round(bos.getTAKE_PROFIT()*10000)/100 +"%" +
							" | bottom-Donchian:"+bos.getFLOOR_CCI() +
							" | top-Donchian:"+bos.getCEILING_CCI() + "\n");
				}
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e.toString());
		} finally {
			if (session != null)
				session.dispose();
		}
	}

}
