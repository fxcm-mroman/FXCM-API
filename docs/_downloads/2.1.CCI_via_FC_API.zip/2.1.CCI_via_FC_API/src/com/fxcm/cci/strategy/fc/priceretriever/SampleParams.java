package com.fxcm.cci.strategy.fc.priceretriever;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class SampleParams {

	public static final String MISSING_PARAMETERS = "Some sample parameters are missing";
	public static final String INSTRUMENT_NOT_SPECIFIED = "'Instrument' not specified. For example: 'EUR/USD'";
	public static final String TIMEFRAME_NOT_SPECIFIED = "'Timeframe' not specified. For example: 'm1'";
	public static final String INVALID_START_DATE = "'start date' must be in the past";
	public static final String START_DATE_LATER_THAN_END_DATE = "'start date' cannot be later than 'end date'";
	private String instrument;
	private String timeframe;
	private Calendar startDate;
	private Calendar endDate;

	public SampleParams(String instrument, String timeframe, String startDate, String endDate) throws Exception {
		this.instrument = instrument;
		this.timeframe = timeframe;
		checkObligatoryParams(); // if instrument and time frame aren't provided
									// -> throw exception
		if (!(startDate.isEmpty() && endDate.isEmpty()))
			checkDateParams(startDate, endDate);
		printParams();
	}

	public SampleParams(String[] args) throws Exception {
		if (args.length < 6)
			throw new Exception(MISSING_PARAMETERS);
		// get obligatory parameters
		this.instrument = args[4];
		this.timeframe = args[5];
		checkObligatoryParams();
		if (args.length > 7) {
			String startDate = args[6];
			String endDate = args[7];
			if (!(startDate.isEmpty() && endDate.isEmpty()))
				checkDateParams(startDate, endDate);
		}
		printParams();
	}

	// getters goes here...
	
	
	
	private void checkObligatoryParams() throws Exception {
		if (this.instrument.isEmpty())
			throw new Exception(INSTRUMENT_NOT_SPECIFIED);
		if (this.timeframe.isEmpty())
			throw new Exception(TIMEFRAME_NOT_SPECIFIED);
	}

	public String getInstrument() {
		return instrument;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public String getTimeframe() {
		return timeframe;
	}

	public void setTimeframe(String timeframe) {
		this.timeframe = timeframe;
	}

	public Calendar getStartDate() {
		return startDate;
	}

	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}

	public Calendar getEndDate() {
		return endDate;
	}

	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	private void printParams() {
		DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
		System.out.println(String.format(
				"Data request properties:\nInstrument='%s', Timeframe='%s', Start Date='%s', End Date='%s'\n",
				this.instrument, this.timeframe, this.startDate == null ? "" : df.format(this.startDate.getTime()),
				this.endDate == null ? "" : df.format(this.endDate.getTime())));
	}

	private void checkDateParams(String startDate, String endDate) throws Exception {
		DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
		df.setLenient(false); // make date validation more strict
		if (!startDate.isEmpty()) {
			this.startDate = Calendar.getInstance();
			this.startDate.setTime(df.parse(startDate));
			if (!this.startDate.before(Calendar.getInstance(TimeZone.getTimeZone("UTC"))))
				throw new Exception(INVALID_START_DATE);
		}
		if (!endDate.isEmpty()) {
			this.endDate = Calendar.getInstance();
			this.endDate.setTime(df.parse(endDate));
		}
		if (!startDate.isEmpty() && !endDate.isEmpty()) {
			if (this.startDate.after(this.endDate))
				throw new Exception(START_DATE_LATER_THAN_END_DATE);
		}
	}

}
