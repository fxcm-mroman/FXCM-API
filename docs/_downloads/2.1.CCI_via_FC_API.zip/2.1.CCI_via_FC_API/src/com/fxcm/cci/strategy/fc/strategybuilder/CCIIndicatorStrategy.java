package com.fxcm.cci.strategy.fc.strategybuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fxcm.cci.strategy.fc.priceretriever.Candlestick;

public class CCIIndicatorStrategy implements Strategy {

	private double STOP_LOSS;
	private double TAKE_PROFIT;
	public static int FLOOR_CCI;
	public static int CEILING_CCI;
	public static final double FACTOR = 0.015;

	public CCIIndicatorStrategy(double sTOP_LOSS, double tAKE_PROFIT, int fLOOR_CCI) {
		super();
		STOP_LOSS = sTOP_LOSS;
		TAKE_PROFIT = tAKE_PROFIT;
		FLOOR_CCI = fLOOR_CCI;
		CEILING_CCI = 0 - fLOOR_CCI;
	}

	public static void calculateCciForDataSet(List<Candlestick> candleSticksList, int duration){
		
		double sum = 0;
		double typicalPriceInstance = 0;
		double smaOfTypicalPrices = 0;
		double cci = 0;
		double meanDeviation = 0;
		double sumOfDeviations = 0;
		List<Double>typicalPrices = new ArrayList<>();


		for (int j = 0; j < duration; j++) {
			//Creation of Class instances
			TypicalPriceIndicator typicalPriceIn = new TypicalPriceIndicator();
			SMAIndicator smaIndicator = new SMAIndicator();
			MeanDeviationIndicator meanDeviationIn = new MeanDeviationIndicator();
			CCIIndicator cciInd = new CCIIndicator();
			
			//Calculation of Typical Price
			typicalPriceIn.calculateTypicalPrice(candleSticksList, duration);
			typicalPrices.add(typicalPriceIn.calculateTypicalPrice(candleSticksList, duration));
			
			//Calculation of SMA of  Typical Prices
			smaOfTypicalPrices = smaIndicator.calculateSMA(typicalPrices, duration);
			meanDeviation = meanDeviationIn.calculateMeanDeviation(smaOfTypicalPrices, typicalPrices, duration);
			
			//Calculation of CCI
			cci = cciInd.calculateCCI(typicalPrices, smaOfTypicalPrices,FACTOR, meanDeviation, duration);
			
			//Set the CCI for each candle
			for (Candlestick candle : candleSticksList) {
				candle.setCci(cci);
			}
		}
	}
	@Override
	public StrategyResult runStrategy(List<Candlestick> candleSticksList) {

		double entryBuy;
		double entrySell;
		double stopLossPrice=0;
		double takeProfitPrice=0;
		double strategyProfit=0;
		double maxProfit=0;
		double maxDrawdown=0;
		boolean isOpenPosition=false;
		int winCounter=0;
		int lossCounter=0;


		for (int i = 250; i < candleSticksList.size(); i++) {

			if(isOpenPosition) {
				if(stopLossPrice<takeProfitPrice) {
					if(candleSticksList.get(i).getLow()<stopLossPrice) {
						isOpenPosition=false;
						lossCounter++;
						strategyProfit-=STOP_LOSS;
						maxDrawdown=calculateMaxDrawdown(maxProfit, strategyProfit, maxDrawdown);
					}else if(candleSticksList.get(i).getHigh()>takeProfitPrice) {
						isOpenPosition=false;
						winCounter++;
						strategyProfit+=TAKE_PROFIT;
						maxProfit=updateMaxProfit(strategyProfit,maxProfit);
					}
				}else {
					if(candleSticksList.get(i).getHigh()>stopLossPrice) {
						isOpenPosition=false;
						lossCounter++;
						strategyProfit-=STOP_LOSS;
					}else if(candleSticksList.get(i).getHigh()>stopLossPrice) {
						isOpenPosition=false;
						winCounter++;
						strategyProfit+=TAKE_PROFIT;
						maxProfit=updateMaxProfit(strategyProfit, maxProfit);
					}
				}
				//System.out.println(candleSticksList.get(i).getCCI() + "THis is the CCI for the FLOOR");
			}else if(candleSticksList.get(i).getCci()<FLOOR_CCI) {
				entryBuy=candleSticksList.get(i).getCloseAsk();
				stopLossPrice= ((1-STOP_LOSS)*entryBuy);
				takeProfitPrice = ((1+TAKE_PROFIT)*entryBuy);
				isOpenPosition=true;
			}else if(candleSticksList.get(i).getCci()>CEILING_CCI) {
				entrySell=candleSticksList.get(i).getCloseBid();
				stopLossPrice=((1+STOP_LOSS)*entrySell);
				takeProfitPrice=((1-TAKE_PROFIT)*entrySell);
				isOpenPosition=true;
			}
		}
		StrategyResult sr = new StrategyResult(strategyProfit, maxProfit, maxDrawdown, winCounter, lossCounter, this);

		return sr;
	}

	private double updateMaxProfit(double strategyProfit, double maxProfit) {

		if(strategyProfit>maxProfit) {
			maxProfit=strategyProfit;
		}

		return maxProfit;
	}

	private double calculateMaxDrawdown(double maxProfit, double strategyProfit, double maxDrawdown) {

		double currentDrawdown = ((1+strategyProfit) - (1+maxProfit))/(1+maxProfit);

		if (currentDrawdown<maxDrawdown) {
			maxDrawdown=currentDrawdown;
		}

		return maxDrawdown;
	}

	public double getSTOP_LOSS() {
		return STOP_LOSS;
	}

	public void setSTOP_LOSS(double sTOP_LOSS) {
		STOP_LOSS = sTOP_LOSS;
	}

	public double getTAKE_PROFIT() {
		return TAKE_PROFIT;
	}

	public void setTAKE_PROFIT(double tAKE_PROFIT) {
		TAKE_PROFIT = tAKE_PROFIT;
	}

	public int getFLOOR_CCI() {
		return FLOOR_CCI;
	}

	public void setFLOOR_CCI(int fLOOR_CCI) {
		FLOOR_CCI = fLOOR_CCI;
	}

	public int getCEILING_CCI() {
		return CEILING_CCI;
	}

	public void setCEILING_CCI(int cEILING_CCI) {
		CEILING_CCI = cEILING_CCI;
	}

	public static double getFactor() {
		return FACTOR;
	}



}
