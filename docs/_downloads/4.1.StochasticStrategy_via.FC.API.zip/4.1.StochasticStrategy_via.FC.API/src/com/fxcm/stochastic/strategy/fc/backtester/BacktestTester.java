package com.fxcm.stochastic.strategy.fc.backtester;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import com.fxcm.stochastic.strategy.fc.priceRetriever.*;
import com.fxcm.stochastic.strategy.fc.strategyBuilder.*;
import com.fxcore2.*;

public class BacktestTester {

	static List<CandleStick> candleSticksList;

	public static void main(String[] args) {
		O2GSession session = null;
		int bottomLimit = 80;
		double stopLoss = 0.003;
		double takeProfit = 0.003;
		List<CandleStick> candleSticksList;
		List<StrategyResult> strategySummary = new ArrayList<StrategyResult>();

		try {
			LoginParams loginParams = new LoginParams("d101592791", "d101592791",
					"http://www.fxcorporate.com/Hosts.jsp", "Demo");
			SampleParams sampleParams = new SampleParams("AUD/USD", "m1", "01.11.2017 00:00", "01.12.2017 00:00");
			// if you supply parameters from the command line
			/*
			 * LoginParams loginParams = new LoginParams(args); SampleParams
			 * sampleParams = new SampleParams(args);
			 */
			// Tester class continued...
			session = O2GTransport.createSession();
			SessionStatusListener statusListener = new SessionStatusListener();
			session.subscribeSessionStatus(statusListener);
			session.login(loginParams.getLogin(), loginParams.getPassword(), loginParams.getUrl(),
					loginParams.getConnection());
			if (statusListener.waitEvents() && statusListener.isConnected()) {
				// connected...
				ResponseListener responseListener = new ResponseListener();
				session.subscribeResponse(responseListener);
				HistoryMiner.getHistoricalPrices(session, sampleParams, responseListener);
				session.logout();
				statusListener.waitEvents();
				session.unsubscribeResponse(responseListener);
			} else {
				System.out.println("Timeout expired before connection could be established");
			}
			session.unsubscribeSessionStatus(statusListener);
			if (HistoryMiner.candlesticksList != null) {
				candleSticksList=HistoryMiner.candlesticksList;
				RangeStrategy.calculateStochasticsD(candleSticksList, 20);
				RangeStrategy.calculateStochasticsK(candleSticksList, 20);
				for (double i = stopLoss; i < stopLoss+0.010 ; i+=0.0005) { 
					for (double j = takeProfit; j < takeProfit+0.05; j+=0.0005) { 
						for (int k = bottomLimit; k <= bottomLimit+20; k+=5) { 
							Strategy rangeStrategy = new RangeStrategy(i, j, k);
							StrategyResult sr = ((RangeStrategy) rangeStrategy).runStrategy(candleSticksList);
							strategySummary.add(sr);
						}
					}
				}
				Collections.sort(strategySummary, new StrategyResult()); 
				double avergeProfit=StrategyResult.calculateAvgStrategyProfit(strategySummary);
				System.out.println("Average profit=> "+(double)Math.round(10000*avergeProfit)/100+"%");

				System.out.println("10 best results ______________________________________________________________ ");
				for (int i = 0; i < 10; i++) {
					RangeStrategy rs = (RangeStrategy) strategySummary.get(i).getStrategy();
					System.out.println("profit:"+(double)Math.round(strategySummary.get(i).getProfit()*10000)/100 +"%" +
							" | max-drawdown:"+(double)Math.round(strategySummary.get(i).getMaxDrawdown()*10000)/100 +"%" +
							" | wins:"+(double)Math.round(10000*strategySummary.get(i).getWinsRatio())/100 + "%" +
							" | losses:"+(double)Math.round(10000*strategySummary.get(i).getLossesRatio())/100 + "%" +
							" | s-l:"+(double)Math.round(rs.getStopLoss()*10000)/100 +"%" +
							" | t-p:"+(double)Math.round(rs.getTakeProfit()*10000)/100 +"%" +
							" | bottom-rsi:"+ rs.getSupportLevel() +
							" | top-rsi:"+ rs.getResistanceLevel() + "\n");
				}

				System.out.println("10 worst results _____________________________________________________________ ");
				for (int i = strategySummary.size()-1; i > strategySummary.size()-11; i--) {
					RangeStrategy rs = (RangeStrategy) strategySummary.get(i).getStrategy();
					System.out.println("profit: "+(double)Math.round(strategySummary.get(i).getProfit()*10000)/100+"%" +
							" | max-drawdown:"+(double)Math.round(strategySummary.get(i).getMaxDrawdown()*10000)/100 +"%" +
							" | wins:"+(double)Math.round(10000*strategySummary.get(i).getWinsRatio())/100 + "%" +
							" | losses:"+(double)Math.round(10000*strategySummary.get(i).getLossesRatio())/100 + "%" +
							" | s-l:"+(double)Math.round(rs.getStopLoss()*10000)/100 +"%" +
							" | t-p:"+(double)Math.round(rs.getTakeProfit()*10000)/100 +"%" +
							" | bottom-rsi:"+rs.getSupportLevel() +
							" | top-rsi:"+rs.getResistanceLevel() + "\n");
				}

			}
		} catch (Exception e) {
			System.out.println("Exception: " + e.toString());
		} finally {
			if (session != null)
				session.dispose();
		}
	}

}
