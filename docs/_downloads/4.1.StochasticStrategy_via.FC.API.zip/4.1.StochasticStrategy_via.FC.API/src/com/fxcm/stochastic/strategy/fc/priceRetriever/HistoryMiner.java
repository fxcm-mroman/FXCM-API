package com.fxcm.stochastic.strategy.fc.priceRetriever;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeSet;
import com.fxcore2.O2GCandleOpenPriceMode;
import com.fxcore2.O2GMarketDataSnapshotResponseReader;
import com.fxcore2.O2GRequest;
import com.fxcore2.O2GRequestFactory;
import com.fxcore2.O2GResponse;
import com.fxcore2.O2GResponseReaderFactory;
import com.fxcore2.O2GResponseType;
import com.fxcore2.O2GSession;
import com.fxcore2.O2GTimeframe;

public class HistoryMiner {

	public static List<CandleStick> candlesticksList;
	static final HashMap<Date, CandleStick> historicalRates = new HashMap<>();
	static SimpleDateFormat dateFormat = new SimpleDateFormat("MM.dd.yyyy HH:mm");
	private static int dataCounter;

	public static void getHistoricalPrices(O2GSession session, SampleParams sampleParams,
			ResponseListener responseListener) throws Exception {
		String instrument = sampleParams.getInstrument();
		String aTimeframe = sampleParams.getTimeframe();
		Calendar startDate = sampleParams.getStartDate();
		Calendar endDate = sampleParams.getEndDate();
		O2GRequestFactory factory = session.getRequestFactory();
		O2GTimeframe timeframe = factory.getTimeFrameCollection().get(aTimeframe);
		if (timeframe == null) {
			throw new Exception(String.format("Timeframe '%s' is incorrect!", aTimeframe));
		}
		O2GRequest request = factory.createMarketDataSnapshotRequestInstrument(instrument, timeframe, 300);
		if (request == null) {
			throw new Exception("Could not create request.");
		}
		Calendar currentIterationEndDate = endDate;
		/*
		 * if the user does not provide a start date, the start date will be the
		 * earliest date FXCM has data for the specified asset
		 */
		if (startDate == null) {
			startDate = Calendar.getInstance();
			startDate.setTime(new Date(Long.MIN_VALUE));
		}
		// HistoryMiner continued...
		do {
			factory.fillMarketDataSnapshotRequestTime(request, startDate, currentIterationEndDate, false,
					O2GCandleOpenPriceMode.PREVIOUS_CLOSE);
			responseListener.setRequestID(request.getRequestId());
			session.sendRequest(request);
			if (!responseListener.waitEvents()) {
				throw new Exception("Response waiting timeout expired");
			}
			O2GResponse response = responseListener.getResponse();
			if (response != null && response.getType() == O2GResponseType.MARKET_DATA_SNAPSHOT) {
				O2GResponseReaderFactory readerFactory = session.getResponseReaderFactory();
				if (readerFactory != null) {
					O2GMarketDataSnapshotResponseReader reader = readerFactory.createMarketDataSnapshotReader(response);
					if (reader.size() > 0) {
						convertResponseToCandlesticks(reader);
						dataCounter += reader.size();
						// print information regarding data for current response
						System.out.println("\nFirst candle date = " + dateFormat.format(reader.getDate(0).getTime())
								+ "\nLast candle date = "
								+ dateFormat.format(reader.getDate(reader.size() - 1).getTime())
								+ "\nTotal candlesticks received: " + dataCounter
								+ "\n_________________________________________");
						if (currentIterationEndDate == null
								|| currentIterationEndDate.compareTo(reader.getDate(0)) != 0) {
							// set end date for next iteration
							currentIterationEndDate = reader.getDate(0);
						} else {
							break;
						}
					} else {
						System.out.println("0 rows received");
						break;
					}
				}
			} else {
				break;
			}
		} while (currentIterationEndDate.after(startDate));
		convertMapToList(historicalRates);
	}

	private static void convertResponseToCandlesticks(O2GMarketDataSnapshotResponseReader reader) {
		for (int i = reader.size() - 1; i >= 0; i--) {
			CandleStick candlestick = new CandleStick(reader.getDate(i).getTime(), reader.getBidOpen(i),
					reader.getBidLow(i), reader.getBidHigh(i), reader.getBidClose(i), reader.getAskClose(i), reader.getVolume(i));
			historicalRates.put(candlestick.getDate(), candlestick);
		}
	}

	private static void convertMapToList(HashMap historicalRates) {
		candlesticksList = new ArrayList<CandleStick>();
		// get the keys of the historicalRates map into a sorted list
		SortedSet<Date> dateList = new TreeSet<>(historicalRates.keySet());
		// go through the keys of the historicalRates map
		for (Date date : dateList) {
			CandleStick candlestick = (CandleStick) historicalRates.get(date);
			candlesticksList.add(candlestick);
		}
	}

	public static void printHistoricalPrices(List<CandleStick> candlesticksList) {
		dateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		System.out.println("Date\t Time\t\tOpen\tHigh\tLow\tClose");
		for (CandleStick candlestick : candlesticksList) {
			String sDate = dateFormat.format(candlestick.getDate());
			System.out.println(sDate + "\t" + candlestick.getOpen() + "\t" + candlestick.getHigh() + "\t"
					+ candlestick.getLow() + "\t" + candlestick.getCloseBid() + "\t" + candlestick.getCloseBid());
		}
	}
}
