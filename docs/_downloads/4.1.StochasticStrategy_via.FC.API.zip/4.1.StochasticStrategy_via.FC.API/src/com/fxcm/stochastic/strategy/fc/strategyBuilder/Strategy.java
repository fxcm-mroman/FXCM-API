package com.fxcm.stochastic.strategy.fc.strategyBuilder;

import java.util.List;

import com.fxcm.stochastic.strategy.fc.priceRetriever.*;

public interface Strategy {
		
	StrategyResult runStrategy(List<CandleStick> candleStickList);
}
