package com.fxcm.stochastic.strategy.fc.strategyBuilder;

import java.util.ArrayList;
import java.util.List;

import javax.xml.crypto.dsig.spec.HMACParameterSpec;

import com.fxcm.stochastic.strategy.fc.priceRetriever.*;

public class DisplayResults {
	
	double representResults = 0; 
	String percentSign = "%";
	
	public void displayHistory(List<com.fxcm.stochastic.strategy.fc.priceRetriever.CandleStick>candleStickList){
		if(candleStickList.size()<1) {
			Utilities.writeString("NO data to display");
			return;
		}
		Utilities.writeString("Date\t Time\t\tOpen\tHigh\tLow\tClose");
		for(CandleStick candleStick : candleStickList) {
			Utilities.writeString(candleStick.getDate() + "\t" +
					candleStick.getOpen() + "\t" + 
					candleStick.getHigh() + "\t" + 
					candleStick.getLow() + "\t"  + 
					candleStick.getCloseBid ()   + 
					candleStick.getCloseAsk());
		}
	}
	
	public void displayBestWinningsFromBacktesting(List <StrategyResult> strategySummary) {
		Utilities.writeString("10 best results ______________________________________________________________ ");
		for (int i = 0; i < 10; i++) {
			RangeStrategy bos = (RangeStrategy) strategySummary.get(i).getStrategy();
			Utilities.writeString("profit:"+(double)Math.round(strategySummary.get(i).getProfit()*10000)/100 +"%" +
					" | max-drawdown:"+(double)Math.round(strategySummary.get(i).getMaxDrawdown()*10000)/100 +"%" +
					" | wins:"+(double)Math.round(10000*strategySummary.get(i).getWinsRatio())/100 + "%" +
					" | losses:"+(double)Math.round(10000*strategySummary.get(i).getLossesRatio())/100 + "%" +
					" | s-l:"+(double)Math.round(bos.getStopLoss()*10000)/100 +"%" +
					" | t-p:"+(double)Math.round(bos.getTakeProfit()*10000)/100 +"%" +
					" | bottom-Donchian:"+bos.getSupportLevel() +
					" | top-Donchian:"+bos.getResistanceLevel() + "\n");
		}
	}
	public void displayWorstWinningsFromBacktesting(List <StrategyResult> strategySummary) {
		Utilities.writeString("10 worst results _____________________________________________________________ ");
		for (int i = strategySummary.size()-1; i > strategySummary.size()-11; i--) {
			RangeStrategy bos = (RangeStrategy) strategySummary.get(i).getStrategy();
			Utilities.writeString("profit:"+(double)Math.round(strategySummary.get(i).getProfit()*10000)/100 +"%" +
					" | max-drawdown:"+(double)Math.round(strategySummary.get(i).getMaxDrawdown()*10000)/100 +"%" +
					" | wins:"+(double)Math.round(10000*strategySummary.get(i).getWinsRatio())/100 + "%" +
					" | losses:"+(double)Math.round(10000*strategySummary.get(i).getLossesRatio())/100 + "%" +
					" | s-l:"+(double)Math.round(bos.getStopLoss()*10000)/100 +"%" +
					" | t-p:"+(double)Math.round(bos.getTakeProfit()*10000)/100 +"%" +
					" | bottom-Donchian:"+bos.getSupportLevel() +
					" | top-Donchian:"+bos.getResistanceLevel() + "\n");
		}
	}
}
