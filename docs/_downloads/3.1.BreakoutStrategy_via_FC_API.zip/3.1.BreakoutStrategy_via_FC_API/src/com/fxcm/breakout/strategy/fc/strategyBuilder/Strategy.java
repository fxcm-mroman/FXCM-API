package com.fxcm.breakout.strategy.fc.strategyBuilder;

import java.util.List;

import com.fxcm.breakout.strategy.fc.priceRetriever.*;

public interface Strategy {
	StrategyResult runStrategy(List<Candlestick> candleSticksList);
}
