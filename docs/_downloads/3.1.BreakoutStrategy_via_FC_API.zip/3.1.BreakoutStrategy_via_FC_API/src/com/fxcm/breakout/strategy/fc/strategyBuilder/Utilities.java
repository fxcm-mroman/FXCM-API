package com.fxcm.breakout.strategy.fc.strategyBuilder;

import java.util.ArrayList;
import java.util.List;

public class Utilities { 
	
	public static void writeString(String text) {
		System.out.println(text);
	}
	
	public static Double addAllNumbers(List<Double> twentyDayHighs){
		double sumOfNumbers = twentyDayHighs.stream().mapToDouble(Double::doubleValue).sum();
//		double sum = 0;
//		for (int i = 0; i < twentyDayHighs.size(); i++) {
//			sum += twentyDayHighs.get(i);
//		}
		return sumOfNumbers;
	} 
	
	
	
}
