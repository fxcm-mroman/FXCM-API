please add fxcore2.jar in libararies
C:\Program Files\Candleworks\ForexConnectAPIx64\bin\java\fxcore2.jar

VM arguments:
-Djava.library.path=.;./java

Working directory
C:\Program Files\Candleworks\ForexConnectAPIx64\bin