package com.fxcm.meanReversion.strategy.fc.priceRetriever;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import com.fxcore2.*;

public class ResponseListener implements IO2GResponseListener {
	private String requestID;
	private O2GResponse response;
	private Semaphore semaphore;

	public ResponseListener() {
		requestID = "";
		response = null;
		semaphore = new Semaphore(0);
	}

	public void setRequestID(String requestID) {
		response = null;
		this.requestID = requestID;
	}

	public O2GResponse getResponse() {
		return response;
	}

	@Override
	public void onRequestCompleted(String requestId, O2GResponse response) {
		if (this.requestID.equals(response.getRequestId())) {
			this.response = response;
			semaphore.release();
		}
	}

	@Override
	public void onRequestFailed(String requestID, String error) {
		if (this.requestID.equals(requestID)) {
			this.response = null;
			if (error.isEmpty()) {
				System.out.println("There is no more data");
			} else {
				System.out.println("Request failed: " + error);
			}
			semaphore.release();
		}
	}

	@Override
	public void onTablesUpdates(O2GResponse response) {
	}

	public boolean waitEvents() throws Exception {
		return semaphore.tryAcquire(30, TimeUnit.SECONDS);
	}
}
