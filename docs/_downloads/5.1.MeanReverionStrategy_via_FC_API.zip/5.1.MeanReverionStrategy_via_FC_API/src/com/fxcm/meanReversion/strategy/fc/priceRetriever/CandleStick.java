package com.fxcm.meanReversion.strategy.fc.priceRetriever;

import java.util.Date;

public class CandleStick {

	private Date date;
	private double open;
	private double low;
	private double high;
	private double closeBid;
	private double closeAsk;
	private double slowSMA;
	private double fastSMA;
	public double averageSMA;
	private double volume;

	public CandleStick(Date date, double open, double low, double high, double closeBid, double closeAsk,
			double volume) {
		this.date = date;
		this.open = open;
		this.low = low;
		this.high = high;
		this.closeBid = closeBid;
		this.closeAsk = closeAsk;
		this.volume = volume;
	}

	public CandleStick(Date date, double open, double low, double high, double closeBid, double closeAsk,
			double slowSMA, double fastSMA, double averageSMA, double volume) {
		super();
		this.date = date;
		this.open = open;
		this.low = low;
		this.high = high;
		this.closeBid = closeBid;
		this.closeAsk = closeAsk;
		this.slowSMA = slowSMA;
		this.fastSMA = fastSMA;
		this.averageSMA = averageSMA;
		this.volume = volume;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getOpen() {
		return open;
	}

	public void setOpen(double open) {
		this.open = open;
	}

	public double getLow() {
		return low;
	}

	public void setLow(double low) {
		this.low = low;
	}

	public double getHigh() {
		return high;
	}

	public void setHigh(double high) {
		this.high = high;
	}

	public double getCloseBid() {
		return closeBid;
	}

	public void setCloseBid(double closeBid) {
		this.closeBid = closeBid;
	}

	public double getCloseAsk() {
		return closeAsk;
	}

	public void setCloseAsk(double closeAsk) {
		this.closeAsk = closeAsk;
	}

	public double getSlowSMA() {
		return slowSMA;
	}

	public void setSlowSMA(double slowSMA) {
		this.slowSMA = slowSMA;
	}

	public double getFastSMA() {
		return fastSMA;
	}

	public void setFastSMA(double fastSMA) {
		this.fastSMA = fastSMA;
	}

	public double getAverageSMA() {
		return averageSMA;
	}

	public void setAverageSMA(double averageSMA) {
		this.averageSMA = averageSMA;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}
}