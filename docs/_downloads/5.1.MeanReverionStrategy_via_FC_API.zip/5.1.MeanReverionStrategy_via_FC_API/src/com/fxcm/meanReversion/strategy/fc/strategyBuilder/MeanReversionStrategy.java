package com.fxcm.meanReversion.strategy.fc.strategyBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.plaf.basic.BasicBorders.MarginBorder;

import com.fxcm.meanReversion.strategy.fc.strategyBuilder.StrategyResult;
import com.fxcm.meanReversion.strategy.fc.priceRetriever.*;

public class MeanReversionStrategy implements Strategy {
	public double stopLoss;
	public double takeProfit;

	public double getStopLoss() {
		return stopLoss;
	}

	public void setStopLoss(double stopLoss) {
		this.stopLoss = stopLoss;
	}

	public double getTakeProfit() {
		return takeProfit;
	}

	public MeanReversionStrategy(double stopLoss, double takeProfit) {
		super();
		this.stopLoss = stopLoss;
		this.takeProfit = takeProfit;
	}

	public MeanReversionStrategy() {
		// TODO Auto-generated constructor stub
	}

	public void setTakeProfit(double takeProfit) {
		this.takeProfit = takeProfit;
	}

	public void calculateFastMovingAverage(List<CandleStick>candleSticksList) {
		List<Double> shliokavica = new ArrayList<>();
		double fastSMA = 0;
		for (int i = 0; i < candleSticksList.size(); i++) {
			double sumOfAllSlowBids = 0; 
			List<Double> listOfAllSlowBids = new ArrayList<>();
			for (int j = 0; j < 20; j++) {
				listOfAllSlowBids.add(candleSticksList.get(j).getCloseBid());
				sumOfAllSlowBids = Utilities.addAllNumbers(listOfAllSlowBids)/20;
			}
			shliokavica = listOfAllSlowBids;
			fastSMA = sumOfAllSlowBids;
			candleSticksList.get(i).setFastSMA(fastSMA);
		}
	}

	public void calculateSlowMovingAverage(List<CandleStick>candleSticksList) {
		List<Double> shliokavica = new ArrayList<>();
		double slowSMA = 0;
		for (int i = 0; i < candleSticksList.size(); i++) {
			double sumOfAllSlowBids = 0; 
			List<Double> listOfAllSlowBids = new ArrayList<>();
			for (int j = 0; j < 50; j++) {
				listOfAllSlowBids.add(candleSticksList.get(j).getCloseBid());
				sumOfAllSlowBids = Utilities.addAllNumbers(listOfAllSlowBids)/50;
			}
			shliokavica = listOfAllSlowBids;
			slowSMA = sumOfAllSlowBids;
			candleSticksList.get(i).setSlowSMA(slowSMA);
		}
	}

	public void calculateAverageMovingAverage(List<CandleStick>candleSticksList) {
		List<Double> shliokavica = new ArrayList<>();
		double slowSMA = 0;
		for (int i = 0; i < candleSticksList.size(); i++) {
			double sumOfAllSlowBids = 0; 
			List<Double> listOfAllSlowBids = new ArrayList<>();
			for (int j = 0; j < 14; j++) {
				listOfAllSlowBids.add(candleSticksList.get(j).getCloseBid());
				sumOfAllSlowBids = Utilities.addAllNumbers(listOfAllSlowBids)/14;
			}
			shliokavica = listOfAllSlowBids;
			slowSMA = sumOfAllSlowBids;
			candleSticksList.get(i).setSlowSMA(slowSMA);
		}
	}

	@Override
	public StrategyResult runStrategy(List<CandleStick> candleSticksList) {
		double entryBuy;
		double entrySell;
		double stopLossPrice=0;
		double takeProfitPrice=0;
		double strategyProfit=0;
		double maxProfit=0;
		double maxDrawdown=0;
		boolean isOpenPosition=false;
		int winCounter=0;
		int lossCounter=0;

		for (int i = 250; i < candleSticksList.size(); i++) {
			if(isOpenPosition) {
				if(stopLossPrice<takeProfitPrice) {
					if(candleSticksList.get(i).getLow()<stopLossPrice) {
						isOpenPosition=false;
						lossCounter++;
						strategyProfit-=stopLoss;
						maxDrawdown=calculateMaxDrawdown(maxProfit, strategyProfit, maxDrawdown);
					}else if(candleSticksList.get(i).getHigh()>takeProfitPrice) {
						isOpenPosition=false;
						winCounter++;
						strategyProfit+=takeProfit;
						maxProfit=updateMaxProfit(strategyProfit,maxProfit);
					}
				}else {
					if(candleSticksList.get(i).getHigh()>stopLossPrice) {
						isOpenPosition=false;
						lossCounter++;
						strategyProfit-=stopLoss;
					}else if(candleSticksList.get(i).getHigh()>stopLossPrice) {
						isOpenPosition=false;
						winCounter++;
						strategyProfit+=takeProfit;
						maxProfit=updateMaxProfit(strategyProfit, maxProfit);
					}
				}
			}else if(candleSticksList.get(i).getFastSMA()>candleSticksList.get(i).getSlowSMA() && candleSticksList.get(i).getFastSMA()>candleSticksList.get(i).getAverageSMA()) {
				entryBuy=candleSticksList.get(i).getCloseAsk();
				stopLossPrice= ((1-stopLoss)*entryBuy);
				takeProfitPrice = ((1+takeProfit)*entryBuy);
				isOpenPosition=true;
			}else if(candleSticksList.get(i).getFastSMA()<candleSticksList.get(i).getSlowSMA() && candleSticksList.get(i).getFastSMA()<candleSticksList.get(i).getAverageSMA()) {
				entrySell=candleSticksList.get(i).getCloseBid();
				stopLossPrice=((1+stopLoss)*entrySell);
				takeProfitPrice=((1-takeProfit)*entrySell);
				isOpenPosition=true;
			}
		}
		StrategyResult sr = new StrategyResult(strategyProfit, maxProfit, maxDrawdown, winCounter, lossCounter, this);
		return sr;
	}

	private static double updateMaxProfit(double strategyProfit, double maxProfit) {
		if(strategyProfit>maxProfit) {
			maxProfit=strategyProfit;
		}
		return maxProfit;
	}

	private static double calculateMaxDrawdown(double maxProfit, double strategyProfit, double maxDrawdown) {
		double currentDrawdown = ((1+strategyProfit)-(1+maxProfit))/(1+maxProfit);
		if(currentDrawdown<maxDrawdown) {
			maxDrawdown=currentDrawdown;
		}
		return maxDrawdown;
	}
}






















