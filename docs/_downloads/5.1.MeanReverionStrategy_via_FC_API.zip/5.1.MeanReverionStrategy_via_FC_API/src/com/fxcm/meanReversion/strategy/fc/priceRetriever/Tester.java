package com.fxcm.meanReversion.strategy.fc.priceRetriever;

import java.util.List;
import com.fxcore2.*;

public class Tester {

	static List<CandleStick> candlesticksList;

	public static void main(String[] args) {
		O2GSession session = null;
		try {
			LoginParams loginParams = new LoginParams("d101592791", "d101592791",
					"http://www.fxcorporate.com/Hosts.jsp", "Demo");
			SampleParams sampleParams = new SampleParams("EUR/USD", "m1", "01.10.2017 00:00", "01.12.2017 00:00");
			// if you supply parameters from the command line
			/*
			 * LoginParams loginParams = new LoginParams(args); SampleParams
			 * sampleParams = new SampleParams(args);
			 */
			// Tester class continued...
			session = O2GTransport.createSession();
			SessionStatusListener statusListener = new SessionStatusListener();
			session.subscribeSessionStatus(statusListener);
			session.login(loginParams.getLogin(), loginParams.getPassword(), loginParams.getUrl(),
					loginParams.getConnection());
			if (statusListener.waitEvents() && statusListener.isConnected()) {
				// connected...
				ResponseListener responseListener = new ResponseListener();
				session.subscribeResponse(responseListener);
				HistoryMiner.getHistoricalPrices(session, sampleParams, responseListener);
				session.logout();
				statusListener.waitEvents();
				session.unsubscribeResponse(responseListener);
			} else {
				System.out.println("Timeout expired before connection could be established");
			}
			session.unsubscribeSessionStatus(statusListener);
			if (HistoryMiner.candlesticksList != null) {
				candlesticksList = HistoryMiner.candlesticksList;
				HistoryMiner.printHistoricalPrices(candlesticksList);
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e.toString());
		} finally {
			if (session != null)
				session.dispose();
		}
	}

}
