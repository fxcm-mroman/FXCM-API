package com.fxcm.meanReversion.strategy.fc.strategyBuilder;

import java.util.List;

import com.fxcm.meanReversion.strategy.fc.priceRetriever.*;

public interface Strategy {
		
	StrategyResult runStrategy(List<CandleStick> candleStickList);
}
